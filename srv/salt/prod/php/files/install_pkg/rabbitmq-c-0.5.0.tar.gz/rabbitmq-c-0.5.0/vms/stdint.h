/* Simply forward this header to what VMS has */
#include <inttypes.h>
