#ifndef LIBRABBITMQ_CONFIG_H
#define LIBRABBITMQ_CONFIG_H

#define VERSION "v0.1"

#endif
